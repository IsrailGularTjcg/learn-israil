// import {React, Component} from "react";

// export default class CmpntInCmpnt extends Component{
//     render(){
//         const SecondComponent = () =>{
//             return(
//                 <>
//                     <p>secondComponent ===</p>
//                 </>
//             )
//         }
//         return(
//         <>  
//             <h1> msg from CmpntInCmpnt </h1>
//             <SecondComponent />
//         </>
//         )
//     }
// }

import React, {Component} from "react";

export default class CmpntInCmpnt extends Component{
    render(){
        return(
            <>
                israil is calling
                <Inner name="israil" />
            </>
        )
    }
}

const Inner = props => {
    return( <p> {props.name} </p> )
}
