import { Table } from "react-bootstrap";
import Btn from "./Btn";

const Bootstrap = () =>{
    let arr = [
        {name:'israil',age:20,post:['developoer','designer']},
        {name:'saud',age:22,post:['developoer','designer','ui & ux']},
        {name:'amin',age:50,post:['developoer']},
        {name:'asif',age:40,post:['front end developer', 'developer']},
        {name:'mustaq',age:45,post:['Api maker']},
        {name:'hamza',age:20,post:['database handler']}
    ]
    let no = 1;
    return(
        <>
        <br />
        <br />
        <hr />
            <Table>
                <thead>
                    <tr>
                        <td>No</td>
                        <td>Name</td>
                        <td>Age</td>
                        <td>Post</td>
                    </tr>
                </thead>
                <tbody>
                    {
                        arr.map((val,i)=>
                        <tr key={i}>
                            <td>{no}</td>
                            <td>{val.name}</td>
                            <td>{val.age}</td>
                            <td>{val.post.map((values,i)=>
                            <Table key={i} className="border border">
                                <tbody>
                                    <tr>
                                        <td className="text-center"><Btn data={values}/></td>     
                                    </tr>
                                </tbody>
                            </Table>
                            )}</td>
                        </tr>
                        )
                    }
                    
                </tbody>
            </Table>
        </>
    )
}
export default Bootstrap;