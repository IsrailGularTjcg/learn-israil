const Btn = props =>{
    return(
        <>
            <button className="btn btn-info">
                {props.data}
            </button>
        </>
    )
}

export default Btn