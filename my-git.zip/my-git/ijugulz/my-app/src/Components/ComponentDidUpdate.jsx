import React from "react";

export default class ComponentDidUpdate extends React.Component{
    constructor(){
        super();
        this.state={
            count:0
        }
        console.log('componentDidUpdate declaring here variables -----> constructor()')
    }

    componentDidMount(){
        console.log('componentDidUpdate loading here jsx -----> componentDidMount()')
    }

    componentDidUpdate(preProps,preState,snapShoot){
        if(this.state.count < 10){
            console.log("::: inside the componentDudUpdate", this.setState({count:this.state.count+1}));
        }
        console.log('componentDidUpdate -----> componentDidUpdate()')
        console.log(':::: old state ::::', preState, ":::: new state ::::", this.state.count,":::snapShoot:::", snapShoot)
        
    }
    
    render(){
        return(
            <>
            <hr />
            {console.log('componentDidUpdate calling here apis -----> render()')}
            <button onClick={()=>{
                this.setState({count:this.state.count+1})
            }}>ComponentDidUpdate</button>
            </>
        )
    }

}