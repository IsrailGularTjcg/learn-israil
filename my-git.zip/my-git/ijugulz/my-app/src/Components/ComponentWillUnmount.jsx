import React from 'react';
 
 export default class ComponentWillUnmount extends React.Component{
    componentWillUnmount(){
        console.log('msg from componentWillUnmoubnt');
    }
    render(){
        return(
            <>message from ComponentWillUnmount</>
        )
    }
}