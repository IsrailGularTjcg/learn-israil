import React from "react";

export default class CompunentDidMount extends React.Component{
    constructor(){
        super();
        console.log('CompunentDidMount declaring here variables -----> constructor()')
    }

    componentDidMount(){
        console.log('CompunentDidMount loading here jsx -----> componentDidMount()')
    }
    
    render(){
        return(
            <>
            {console.log('CompunentDidMount calling here apis -----> render()')}
            </>
        )
    }

}