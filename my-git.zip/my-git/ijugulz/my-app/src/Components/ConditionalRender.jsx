import React from "react"


const ConditionalRender = ()=> {

    const [user,updtUser] = React.useState(0)

    return(
        <>
            <h1>{user === 0? 'helo user 1': user === 1 ? 'helo user 2' : 'helo guest' }</h1>  
        </>
    )
}
export default ConditionalRender