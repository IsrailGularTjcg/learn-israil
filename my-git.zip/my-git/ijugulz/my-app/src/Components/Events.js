let Events = () =>{
    let data = 'calling Events'
    
    let alt = ()=>{
        let data = 'israsil gulzar'
        alert(data);
    }
    return(
        <>
          helo from event compounts1
          <br/>
          <br/>
          first way <br/>
          <button onMouseEnter={alt}> hover me</button>
          <br/>
          <br/>
          second Way <br/>
           <button onClick={()=>alert('this is second way to call events')}> click me</button>
        </>
    )

}

export default Events;