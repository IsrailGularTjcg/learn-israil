import React from "react"
const HideShowToggle = ()=>{
    const [status,updtData] = React.useState(true)
    return(
        <>
        {
            status? <h1>  how are you? </h1> : ''
        }
            <button onClick={()=>{updtData(! status)}}> toggle </button>
        </>
    ) 
}
export default HideShowToggle;