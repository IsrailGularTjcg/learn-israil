import React from "react"

const Child = (props)=>{
    return(
        <>
             <button onClick={()=>props.passFun('israil from child')}>click me</button>
        </>
    )
}
export default Child;