import { Alert } from "bootstrap"
import React from "react"
import Child from "./Child"

const Parent = ()=>{
    let passData = (name)=>{
        alert('name ===>'+ name)
    }
    return(
        <>
            <h1>click to pass the data </h1>
            <Child passFun={passData}/>
        </>
    )
}
export default Parent;