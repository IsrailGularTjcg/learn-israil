import React from "react";

export default class PropsInClass extends React.Component{
   render(){
       return(
           <>
            props in class {this.props.secondName} 
           </>
       )
   } 
}