const PropsInFun = props =>{
    return(
        <>
            <div>
                <ul>
                    <li>name : {props.name} </li>
                    <li>email : {props.email} </li>
                    <li>phone : {props.phone} </li>
                </ul>
            </div>
        </>
    )
}

export default PropsInFun;