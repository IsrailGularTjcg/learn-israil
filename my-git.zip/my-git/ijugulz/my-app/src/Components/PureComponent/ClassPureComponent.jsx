import React, { PureComponent } from 'react';

class ClassPureComponent extends PureComponent {

    constructor(){
        super()
        this.state = {
            count:0
        }
    }

    render() {
        console.log('PureComponent rendering testing');
        return (
            <>
                count of PureComponent : {this.state.count} <br />
                <button onClick={()=> this.setState({count:1})}> click me </button>      
            </>
        );
    }
}

export default ClassPureComponent;

// import React, { PureComponent } from 'react';

// class ClassPureComponent extends PureComponent {

//     constructor(){
//         super()
//         this.state = {
//             count:0
//         }
//     }

//     render() {
//         console.log('PureComponent rendering testing');
//         return (
//             <>
//                 count of PureComponent : {this.state.count} <br />
//                 <button onClick={()=> this.setState({count:1})}> click me </button>      
//             </>
//         );
//     }
// }

// export default ClassPureComponent;