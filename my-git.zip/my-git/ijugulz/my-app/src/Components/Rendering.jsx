import React from "react";

export default class Rendering extends React.Component{
    constructor(){
        super()
    }
    render(){
        console.warn('::: rendering :::');

        return(
            <>open console ... this is rendering for class component</>
        )
    }
}