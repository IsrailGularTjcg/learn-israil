import React from "react";

export default class ComponentWillUnmount extends React.Component{
    constructor(){
        super();
        this.state={
            count:1
        }
        console.log('componentDidUpdate declaring here variables -----> constructor()')
    }

    render(){
        return(
            <>
            <hr />
            {console.log('ComponentWillUnmount calling here-----> render()')}
            <button onClick={()=>{
                this.setState({count:this.state.count+1})
            }}>ComponentWillUnmount <b> {this.state.count}</b></button>
            </>
        )
    }

}