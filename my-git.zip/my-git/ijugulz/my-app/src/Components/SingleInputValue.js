import { useState } from "react";

const SingleInputValue = ()=>{
    let [data,updtData] = useState('')
    let setState = (e)=>{
        updtData(e.target.value)
    }
    return(
       <>
        <p>{data}</p>
        <input onChange={setState} />
       </>
   ); 
}

export default SingleInputValue;