import React,{useState} from "react"

const States = (props) =>{

    let [data,setData] = useState(props.number)
    const updateData = ()=>{
        setData(++data)
    }

    return(
    <>
        <br />
        <hr />
           state are start from here
        <h1> {data} </h1>
        <button onClick={updateData}>count up</button>
        <button onClick={()=>{setData(--data)}}>count down </button>
    </>
    )
}

export default States;