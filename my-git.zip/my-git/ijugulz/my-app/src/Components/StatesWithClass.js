import React from "react";

export default class StatesWithClass extends React.Component{
    constructor(){
        super();
        this.state = {
            data : 0
        }
    }

    updateSum(){
        this.setState({data:this.state.data+1})
    }

    updateSub(){
        this.setState({data:this.state.data-1})
    }

    render(){
        return(
        <>
        <br/>
        <br/>
        <hr/>
        <h2>{this.state.data}</h2>
            <button onClick={()=>{this.updateSum()}}>
                count Up
            </button>
            <button onClick={()=>{this.updateSub()}}>
                count Down
            </button>
        </>
        )
    }
}