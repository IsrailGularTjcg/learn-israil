import '../Style/Style.css'
import styleM from '../Style/styleM.mdule.css'
const Style = ()=>{
let comn = {
    width:100+'%',
    height:5+'rem'
}
    return(
        <>
        <hr />
            <div style={comn}>
                <h3 className='bg-pink'>helo world</h3>
            </div>
            <div style={{background:'red'}}>
                <h3 className={styleM.txtRed}>helo world</h3>
            </div>
        <hr />
        </>
    )
}

export default Style