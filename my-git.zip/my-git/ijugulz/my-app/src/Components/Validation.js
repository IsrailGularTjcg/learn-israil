
import {useState} from "react"

const Validation = (props) =>{

    let [data,setData] = useState(props.number)
    const updateData = ()=>{
        setData(++data)
    }

    const valid = ()=>{
        
    }

    return(
    <>
        <br />
        <hr />
           state are start from here
        <h1> {data} </h1>
        <button onClick={updateData}>count up</button>
        <button onClick={()=>{setData(--data)}}>count down </button>
    </>
    )
}

export default Validation;