import React, { useEffect, useState } from "react"

const VdoUseEffect1 = () =>{

    // let [count, updtCount] =  useState(0)

    useEffect(()=>{
        alert('msg from useEffect 1')
    },[])

    return(
        <>
            <p> useEffect {} count </p>
            <button> useEffect 1 count</button>
        </>
    )
}

export default VdoUseEffect1;