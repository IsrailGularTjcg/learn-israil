import userEvent from "@testing-library/user-event";
import React, { useEffect, useState } from "react";
import VdoUseEffect2Child from "./VdoUseEffect2Child";

const VdoUseEffect2 = ()=>{
    let [count,updtCount] = useState(0);
    let [data,updtData] = useState(0);

    return(
        <>
            <h2>count Use Effect vdo 2 count : {count}</h2>
            <button onClick={()=>updtCount(++count)}>Use Effect vdo 2 btn</button>

            <h2>count Use Effect vdo 2 data : {data}</h2>
            <button onClick={()=>updtData(++data)}>Use Effect vdo 2 btn</button>
            <VdoUseEffect2Child data={data} count={count} />
        </>
    )
}


// const VdoUseEffect2 = ()=>{
//     let [count,updtCount] = useState(0);
//     let [data,updtData] = useState(0);

//     useEffect(()=>{
//         alert('Use Effect vdo 2'+ data)
//     },[data])
//     useEffect(()=>{
//         console.warn('Use Effect vdo 2', count)
//     },[count])

//     return(
//         <>
//             <h2>count Use Effect vdo 2 count : {count}</h2>
//             <button onClick={()=>updtCount(++count)}>Use Effect vdo 2 btn</button>

//             <h2>count Use Effect vdo 2 data : {data}</h2>
//             <button onClick={()=>updtCount(++data)}>Use Effect vdo 2 btn</button>
//         </>
//     )
// }

export default VdoUseEffect2;