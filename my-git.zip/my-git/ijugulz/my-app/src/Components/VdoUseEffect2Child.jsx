import userEvent from "@testing-library/user-event";
import React, { useEffect, useState } from "react";

const VdoUseEffect2Child = props =>{
    
    useEffect(()=>{
        alert('Use Effect vdo 2'+ props.data)
    },[props.data])
    useEffect(()=>{
        console.warn('Use Effect vdo 2', props.count)
    },[props.count])

    return(
        <>
            <h2>count Use Effect vdo 2 count : {props.count}</h2>
            <h2>count Use Effect vdo 2 data : {props.data}</h2>
        </>
    )
}

export default VdoUseEffect2Child;