function Test(props){
    console.log('props ===>', props);
    return(
        <>
            <div>
                {props.name} 
                <br/>
                {props.email}
            </div>
        </>
    )
}

export default Test;