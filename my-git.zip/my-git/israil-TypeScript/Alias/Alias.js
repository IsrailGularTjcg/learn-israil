"use strict";
let a = 'boolen';
let b = [1.2501, 5454524];
console.log('a -->', a, 'b -->', b);
