type varTyp =  number[] | string;

let a : varTyp = 'boolen';
let b : varTyp = [1.2501,5454524]

console.log('a -->', a, 'b -->', b);
