"use strict";
let ex1 = ['israil', 8240, true, 1.52, undefined, null];
console.log('ex1-->', ex1);
let ex2 = undefined;
console.log('ex2 -->', ex2);
