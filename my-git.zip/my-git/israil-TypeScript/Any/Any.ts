let ex1:any[] = ['israil',8240,true,1.52,undefined,null] 

console.log('ex1-->', ex1);


let ex2:any = undefined;

console.log('ex2 -->', ex2);

