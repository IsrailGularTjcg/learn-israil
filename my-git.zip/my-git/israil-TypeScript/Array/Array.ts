let ex1 = ['israil','gulzar',123,true];
console.log('ex1 ==>', ex1);

let ex2:any = ['iju','gulz',555, false]
console.log('ex2 -->', ex2);

let ex3 : [number,string,Boolean] = [1,'<--==-->',true]
console.log('ex3 -->', ex3);

let ex4 : string[] = ['helo','gulzar'];
console.log('ex4 -->', ex4);

let ex5 : [string,boolean?] = ['ijugulz']
ex5.push(true)

console.log('ex5 -->', ex5);


