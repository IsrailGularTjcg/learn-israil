"use strict";
class Class {
    constructor() {
        this.user = '';
    }
    addUser(name) {
        console.log(`user ${name} is addded `);
    }
}
let obj = new Class;
obj.addUser('israil');
