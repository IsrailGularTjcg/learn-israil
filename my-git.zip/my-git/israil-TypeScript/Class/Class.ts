class Abc{
    user:string = '';
    
    addUser( name:string ){
        console.log(`user ${name} is addded `)
    }
}


// let obj = new Abc;



