"use strict";
let num = 10;
let str = '10';
console.log('hi');
console.log('string', str);
function helo(i) {
    console.log('i==><===', i);
}
helo(['israil', { name: 'israil' }, 12354, 1.0]);
console.log(new Error('helo israil gulzar'));
console.log(new Set([1, 1, 1, 48, 52, 95, 48]));
