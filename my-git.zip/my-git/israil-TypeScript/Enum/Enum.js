"use strict";
var Role;
(function (Role) {
    Role[Role["admin"] = 0] = "admin";
    Role[Role["user"] = 1] = "user";
    Role[Role["customer"] = 2] = "customer";
})(Role || (Role = {}));
console.log('Role -->', Role);
console.log('admin ==', Role.admin);
console.log('admin ==', Role[0]);
console.log('admin ==', Role[Role.admin]);
