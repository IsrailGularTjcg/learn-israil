enum Role {
    admin,user,customer
}
console.log('Role -->', Role);

console.log('admin ==', Role.admin);
console.log('admin ==', Role[0]);
console.log('admin ==', Role[Role.admin]);

