"use strict";
const israil = 10;
console.log('num', num);
