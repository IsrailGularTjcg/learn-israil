const israil:number = 10;

console.log('num', num);
