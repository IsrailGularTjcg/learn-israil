"use strict";
let a = (v) => v;
console.log('v is --->', a(10));
