let a = (v):number => v

console.log('v is --->', a(10));
