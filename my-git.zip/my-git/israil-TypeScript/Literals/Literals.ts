let Ex: number | string = 'helo'; 
console.log('ex ==>', ex);

let Ex0:'helo' | true = true
console.log('--ex0--', ex0);
