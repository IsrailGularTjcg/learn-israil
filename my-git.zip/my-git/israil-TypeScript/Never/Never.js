"use strict";
function ig() {
    throw new Error("this is error form never");
}
console.log(ig());
