function ig():void {
    throw new Error("this is error form never");
    
}
console.log(ig());
