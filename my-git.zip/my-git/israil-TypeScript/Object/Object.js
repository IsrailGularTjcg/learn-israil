"use strict";
let obj = {
    name: 'israil',
    isActtive: false,
    age: 22
};
console.log('obj--->', obj);
let object = {
    name: 'muhammad'
};
console.log('object--->', object);
let Type = {
    name: 'iju',
    age: 22
};
