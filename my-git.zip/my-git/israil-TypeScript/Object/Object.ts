let obj = {
    name:'israil',
    isActtive: false,
    age:22
}

console.log('obj--->',obj);

let object:{name:string} = {
    name: 'muhammad'
} 

console.log('object--->',object);

let Type : {name:string,age:number} = {
    name:'iju',
    age:22
}
