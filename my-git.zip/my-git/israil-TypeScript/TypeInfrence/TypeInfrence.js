"use strict";
let a = '';
console.log('helo');
const abc = 5;
let x;
x = 'israil';
x = true;
