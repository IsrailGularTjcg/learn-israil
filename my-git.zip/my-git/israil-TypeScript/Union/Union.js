"use strict";
let a = true;
console.log('a from union', a);
let x = 15.0;
console.log('<--x-->', x);
