"use strict";
let data;
let data1;
data1 = 'helo';
data1 = data;
