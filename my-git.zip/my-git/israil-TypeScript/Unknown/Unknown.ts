let data:unknown;
let data1: string;

data1 = 'helo';

data1 = data