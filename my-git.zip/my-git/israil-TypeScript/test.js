"use strict";
console.log('helo israil', 5 + 5);
