import logo from './logo.svg';
import './App.css';
import GetData from './Components/GetData';

function App() {
  return (
    <div className="App">
      <GetData />
      
    </div>
  );
}

export default App;
