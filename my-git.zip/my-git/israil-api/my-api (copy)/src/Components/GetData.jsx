import React, { useEffect, useState, useLayoutEffect } from 'react';
import Services from '../Services/Services'

function GetData(props) {
    
    const call = async (params)=>{
        try {
            let abc = await Services.getData(params)
            return abc;
        } catch (error) {
            console.log('catch --->', error);
            return error
       }

    }

    useLayoutEffect(()=>{
            console.log('Services call -->', call('posts'));
    },[])

    
    // useEffect(()=>{
    // fetch('https://jsonplaceholder.typicode.com/users').then(result =>{
    //     result.json().then( res =>
    //         {
    //             console.luseEffect
    // })
    
    const [data,setData] = useState([]);
    return (
        <div>
            
        </div>
    );
}

export default GetData;