export default {
    urlType : {
        mainUrl:'https://jsonplaceholder.typicode.com/'
    }
}