import Urls from '../Constant/Constant'

// console.log(' Urls -->', Urls);
// console.log(' Urls -->', Urls.urlType.mainUrl);
export default {
    async getData(endPoint, path = Urls.urlType.mainUrl){
        try{
            await fetch(path + endPoint).then((res)=>{
                res.json().then((r)=>{
                    console.log('r', r)
                    return r
                });
            })
        }catch(e){
            console.log( ':::: getting getData error ::::' + e);
        }
    }
}




// getProductData = ({ id }) => {
//     return new Promise((resolve, reject) => {
//         const request = axios.get(UrlHelper.getProduct)
//         request.then((response) => {

//             const { data, status } = response;
//             if (status == 200) {
//                 resolve({ data });
//             }
//             else if (status == 401) {
//                 // 
//             }
//             else {
//                 reject({ message: 'Error in retrive Data' });
//             }
//         }).catch((error) => {
//             reject({ message: 'Something went wrong!!' });
//         })
//     });
// };
