import logo from './logo.svg';
import './App.css';
import GetData from './Components/GetData';
import Insert from './Components/Insert';
import DeleteData from './Components/DeleteData';
import Update from './Components/Update';
import Update2 from './Components/Update2';
import GetPreviousState from './Components/GetPreviousState';
import GetPreviousProps from './Components/GetPreviousProps';
import StateObjectHndl from './Components/StateObjectHndl';

function App() {
  return (
    <div className="App">
      {/* <GetData /> */}
      <Insert />
      <DeleteData />
      <Update />
      <Update2 />
      <GetPreviousState />
      <GetPreviousProps />
      <StateObjectHndl />
      
    </div>
  );
}

export default App;
