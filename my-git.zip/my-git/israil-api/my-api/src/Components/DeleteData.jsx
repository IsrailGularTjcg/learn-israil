import React, { useEffect, useState, useLayoutEffect } from 'react';
import Services from '../Services/Services'

function DeleteData(props) {
    
    const [data,setData] = useState([]);

    const call = async (params)=>{
        let result;

        try {
            result = await Services.getData(params,);
        } catch (error) {
            result = error
        }

       return result
    }

    const deleteRecord = async (params)=>{
        let result;

        try {
            result = await Services.deleteData(params);
        } catch (error) {
            result = error
        }

       return result
    }

    useEffect(()=>{
        call('users').then((resp)=>{setData(resp)})
    },[])

    return (
        <div>
            <table border="">
                <thead>
                    <tr>
                        <td>Id</td>
                        <td>Name</td>
                        <td>Email</td>
                        <td>Action</td>
                    </tr>
                </thead>
                <tbody>
                {data.map((val,i) =>
                    <tr key={i}>
                        <td>{val.id}</td>
                        <td>{val.name}</td>
                        <td>{val.email}</td>
                        <td><button onClick={()=>deleteRecord({endPoint:'posts/',id : val.id})}>delete</button></td>
                    </tr>
                )} 
                </tbody>
            </table>
           
        </div>
    );
}

export default DeleteData;