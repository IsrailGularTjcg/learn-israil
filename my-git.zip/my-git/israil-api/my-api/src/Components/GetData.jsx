import React, { useEffect, useState } from 'react';
import Services from '../Services/Services'

function GetData(props) {
    
    const [data,setData] = useState([]);

    const call = async (params)=>{
        let result;

        try {
            result = await Services.getData(params);
        } catch (error) {
            result = error
        }

       return result
    }

    useEffect(()=>{
        call('posts').then((resp)=>{setData(resp)})
    },[])

    return (
        <div>
            <table border="">
                <thead>
                    <tr>
                    <td>No</td>
                    <td>Id</td>
                    <td>User Id</td>
                    <td>Body</td>
                    <td>Title</td>
                    </tr>
                </thead>
                <tbody>
                {data.map((val,i) =>
                    <tr key={i}>
                        <td>{i}</td>
                        <td>{val.userId}</td>
                        <td>{val.title}</td>
                        <td>{val.body}</td>
                    </tr>
                )} 
                </tbody>
            </table>
           
        </div>
    );
}

export default GetData;