import React, { useState, useEffect, useRef } from 'react';

function GetPreviousProps(props) {
    
    const [count, updtCount] = useState(0)

        return (
        <div>
            <h1>the pre props prec is : <Props count={count}/></h1>        
            <button onClick={()=>updtCount(Math.floor(Math.random()*10))}>click me</button>
        </div>
    );
}

function Props(props) {
    
    let lastValue = useRef();

    useEffect(()=>{
        lastValue.current = props.count;
    })

    const preProp = lastValue.current;

    return (
        <div>
            <h3>{props.count}</h3>        
            <p>previous value is {preProp}</p>        
        </div>
    );
}

export default GetPreviousProps;
