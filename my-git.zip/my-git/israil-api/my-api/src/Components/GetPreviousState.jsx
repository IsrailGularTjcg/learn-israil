import React, { useState } from 'react';

function GetPreviousState(props) {
    
    const [count, updtCount] = useState(1)
    const updtValue = ()=>{
        
        // logic no 1

        // updtCount((pre)=>{
        //     console.log('the previous val :::', pre);
        //     pre < 5 ? alert('the fullStack Developer Israil') : alert('the MERN Stack Developer Israil')
        //     return count+1;
        // })

        // logic no 2

        for (let i = 0; i < 5; i++) {
            updtCount((pre)=>{
                console.log('pre :::', pre);
            return pre+1;
            })
        }



    }

    return (
        <div>
            <h1>the pre is : {count}</h1>        
            <button onClick={updtValue}>click me</button>
        </div>
    );
}

export default GetPreviousState;