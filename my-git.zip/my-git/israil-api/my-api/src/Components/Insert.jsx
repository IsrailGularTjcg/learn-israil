import React, { useState } from 'react';
import Services from '../Services/Services'


function Insert() {

    const [name,setName] = useState('')
    const [email,setEmail] = useState('')
    const [phone,setPhone] = useState('')

    const saveUser = async ()=>{
        let data = {name, email, phone};
        if(data && Object.keys(data).length > 0){
           await Services.insertData('posts',data);
           alert('data inserted success full')
        }else{
            alert('data not inserted');
        }
    }

    return (
        <div>
            <br />
            <br />
            <br />
            <h1>sign up here</h1>
            <form >
                <input type="text" onChange={(e)=>{setName(e.target.value)}}/> <br /><br />
                <input type="email" onChange={(e)=>{setEmail(e.target.value)}} /> <br /><br />
                <input type="phone" onChange={(e)=>{setPhone(e.target.value)}} /> <br /><br />
                <input type="button" onClick={saveUser} value="SUBMIT" />
            </form>
        </div>
    );
}

export default Insert;