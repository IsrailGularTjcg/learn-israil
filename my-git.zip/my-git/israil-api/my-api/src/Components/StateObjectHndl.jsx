import React, { useState } from 'react';


function StateObjectHndl() {

    const [data, setData] = useState({name:'Israil',lastName:'Gulzar'})
    
    return (
        <div>
            <p> first Name is : {data.name} </p>
            <input type="text" value={data.name} onChange={(e)=> setData({...data, name: e.target.value})} /> <br /><br />
            <p> first Name is : {data.lastName} </p>
            <input type="text" value={data.lastName} onChange={(e)=> setData({...data, lastName: e.target.value})} /> <br /><br />
        </div>
    );
}

export default StateObjectHndl;