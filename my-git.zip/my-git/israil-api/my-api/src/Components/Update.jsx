import React, { useEffect, useState } from 'react';
import Services from '../Services/Services'


function Update() {

    const [name,setName] = useState('')
    const [email,setEmail] = useState('')
    const [phone,setPhone] = useState('')

    const fillData = async (params)=>{
        let result;

        try {
            result = await Services.getData(params);
        } catch (error) {
            result = error
        }

        return result
    }

    
    const fillValues = (opts) =>{
        setName(opts.name)
        setEmail(opts.email)
        setPhone(opts.phone)
    }



    useEffect(()=>{
        //  fillData('users').then( r => console.log("fillData('post')",r[0]));
         fillData('users').then( res => fillValues(res[0]));
        
        // fillData('posts').then((resp)=>{setData(resp)})
    },[])

    return (
        <div>
            <br />
            <br />
            <br />
            <h1>update up here</h1>
            <form >
                <input type="text" value={name} onChange={(e)=>{setName(e.target.value)}}/> <br /><br />
                <input type="email" value={email} onChange={(e)=>{setEmail(e.target.value)}} /> <br /><br />
                <input type="phone" value={phone} onChange={(e)=>{setPhone(e.target.value)}} /> <br /><br />
                <input type="button" onClick={fillData} value="Update" />
            </form>
        </div>
    );
}

export default Update;