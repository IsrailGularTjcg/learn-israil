import React, { useEffect, useState } from 'react';
import Services from '../Services/Services'

function Update2() {

    const [data,setData] = useState([]);

    const [name,setName] = useState('')
    const [email,setEmail] = useState('')
    const [phone,setPhone] = useState('')
    const [userId,setUserId] = useState('')

    const fillData = async (params)=>{
        let result;

        try {
            result = await Services.getData(params);
        } catch (error) {
            result = error
        }

       return result
    }
    
    const fillSingleData = async (opts)=>{
        let result;

        try {
            result = await Services.getData(opts.endPoint,opts.id)
        } catch (error) {
            result = error
        }

        return result;
    }

    const fillForm = (opts) =>{
        setName(opts.name)
        setEmail(opts.email)
        setPhone(opts.phone)
        setUserId(opts.id)
    }

    const updateData = params =>{
        Services.insertData('posts', {email:params.email,name:params.name,phone:params.phone}, params.userId)
        console.log('params -->', params);
    }

    useEffect(()=>{
        fillData('users').then((resp)=>{setData(resp)})
    },[])

    return (
        <>
            <br /> 
            <br />
            <br /> 
            <br /> 
            <br />
            <br />
        <div style={{display:'flex',justifyContent:'space-around'}} >
           
            <table border="">
                <thead>
                    <tr>
                    <td>No</td>
                    <td>Id</td>
                    <td>User Id</td>
                    <td>Body</td>
                    <td>action</td>
                    </tr>
                </thead>
                <tbody>
                {data.map((val,i) =>
                    <tr key={i}>
                        <td>{i+1}</td>
                        <td>{val.name}</td>
                        <td>{val.email}</td>
                        <td>{val.phone}</td>
                        <td><button onClick={()=>fillSingleData({endPoint:'users',id:val.id}).then((res)=> fillForm(res))}>Update</button></td>
                    </tr>
                )} 
                </tbody>
            </table>
            <form >
                <input type="text" value={name} onChange={(e)=>{setName(e.target.value)}}/> <br /><br />
                <input type="email" value={email} onChange={(e)=>{setEmail(e.target.value)}} /> <br /><br />
                <input type="phone" value={phone} onChange={(e)=>{setPhone(e.target.value)}} /> <br /><br />
                <input type="button" onClick={()=>updateData({userId, name, email, phone})} value="Update" />
            </form>
           
        </div>
        </>

    );
}

export default Update2;