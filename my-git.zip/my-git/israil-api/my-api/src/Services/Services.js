import Urls from '../Constant/Constant'

export default {

    getData(endPoint, id, path = Urls.urlType.mainUrl){
        
        return new Promise((resolve,reject)=>{
            
            const req = id && id !== undefined && Number.isInteger(id) ? fetch(`${path}${endPoint}/${id}`) : fetch(`${path}${endPoint}`);

            req.then((res)=>{
                res.json().then((res)=>{
                    if(1){
                        resolve(res); 
                    }
                    else{
                        reject(res); 
                    }
                });
            })
            
        }).catch((error) => {
            console.log('error==>', error);
        })
    },

    insertData(endPoint, data, id = undefined, path = Urls.urlType.mainUrl){
        console.log('data::44', data);
        console.log('data::44', id);
        return new Promise((resolve,reject)=>{

            const action = id === undefined && Number.isInteger(id) ? `${path}${endPoint}` : `${path}${endPoint}/${id}`;

            const req = fetch(action,{
            method: id !== undefined && Number.isInteger(id)? 'PUT' : 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
                body: JSON.stringify(data)
            });     

            req.then((res)=>{
                if(data && Object.keys(data).length > 0){
                    resolve(res)
                }else{
                    reject(res)
                }
            }).catch((e)=>{
                reject(e)
            })

        })
    },

    deleteData(opts, path = Urls.urlType.mainUrl){
        return new Promise((resolve,reject)=>{

           const req = fetch(path + opts.endPoint + opts.id,{
            method:'DELETE'
            });     

            req.then((res)=>{
                if(opts.id && Number.isInteger(opts.id) && opts.id > 0){
                    resolve(res)
                    alert('record deleted successful')
                }else{
                    console.log('elseeee');
                    alert(res + 'record not deleted successful')
                    reject(res)
                }
            }).catch((e)=>{
                reject(e)
            })

        })
    },
    
}
