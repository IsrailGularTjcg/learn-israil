import { useMutation, useQuery } from '@apollo/client';
import { GET_ALL_RECORDS } from './gqloperations/queris';
import './App.css';
import { useState } from 'react';


function App() {  
  const [ sendName , getName  ] = useMutation();
  
  const {loading, error ,data} = useQuery(GET_ALL_RECORDS);
  
  const [name,setName] = useState('')
  
  if(loading) return <h1 align="center"> loading </h1>;
  if(error) return <h1 align="center"> error </h1>;
  
  return (
    <>
    <div className="App">
      {data.locations.map((val,i) =>  
        <span key={i}>
          <p>{val.id}</p> 
          <p>{val.name}</p> 
          <img style={{height:"50px",width:"50px"}} src={val.photo} /> 
        </span>
      )}

    </div>
      <form action="">
        <input type="text" onChange={(e)=>setName(e.target.value)} />
        <input type="submit" onClick={sendName({variables:{
          name
        }})} value="submit" />
    </form>
    </>
  );  
}

export default App;
