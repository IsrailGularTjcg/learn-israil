import { gql } from "@apollo/client";

    export const GET_ALL_RECORDS =  gql`
      query GetLocations {
        locations {
          id
          name
          description
          photo
        }
      }
    `

    export const ADD_AUTH = gql`
        mutation AddAuthor($name: String!) {
            addAuthor(name: $name) {
            name
            id
        }
      }
    `


