import logo from './logo.svg';
import Comp1 from './Cmponents/Comp1'
import './App.css';

function App() {
  return (
    <div className="App">
      <Comp1 />
    </div>
  );
}

export default App;
