import React, { createContext } from 'react';
import Comp2 from './Comp2';

const FirstName = createContext();
const LastName = createContext();

function Comp1(props) {
    return (
        <FirstName.Provider value={'MERN Stack'}>
            <LastName.Provider value={'Full Stack'}>
                <div>
                    <h2> israil gulzar is a :
                        <Comp2 />
                    </h2>
                </div>
            </LastName.Provider>
        </FirstName.Provider>
    );
}

export {FirstName, LastName};

export default Comp1;