import React, {useContext} from 'react';
import { FirstName } from './Comp1';
import Comp3 from './Comp3';

function Comp2(props) {
    let positon = useContext(FirstName) 
    return (
        <div>
            msg fro con 2 : {positon}
            <Comp3 />
        </div>
    );
}

export default Comp2;