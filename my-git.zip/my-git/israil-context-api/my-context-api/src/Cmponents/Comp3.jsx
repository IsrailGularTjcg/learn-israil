import React from 'react';
import {FirstName, LastName} from './Comp1'

function Comp3(props) {
    return (
        <FirstName.Consumer>{
            (name)=>{
            return(
                <div>
                    <LastName.Consumer>{
                        (lname)=>{
                            return(
                                <>msg from {name} {lname} </>
                            )
                        }
                    }</LastName.Consumer>
                </div>
                )
            }
                
        }</FirstName.Consumer>
    );
}

export default Comp3;
