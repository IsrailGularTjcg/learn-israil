import './App.css';
import { useState } from 'react';
import CmpntInCmpnt from './CmpntInCmpnt'
import Events from './Components/Events'
import States from './Components/States'
import StatesWithClass from './Components/StatesWithClass'
import PropsInFun from './Components/PropsInFun'
import PropsInClass from './Components/PropsInClass'
import SingleInputValue from './Components/SingleInputValue'
import HideShowToggle from './Components/HideShowToggle'
import FormHandle from './Components/FormHandle'
import ConditionalRender from './Components/ConditionalRender'
import Rendering from './Components/Rendering'
import CompunentDidMount from './Components/CompunentDidMount'
import ComponentDidUpdate from './Components/ComponentDidUpdate'
import ShouldComponentUpdate from './Components/ShouldComponentUpdate'
import ComponentWillUnmount from './Components/ComponentWillUnmount';
import VdoUseEffect1 from './Components/VdoUseEffect1';
import VdoUseEffect2 from './Components/VdoUseEffect2';
import Style from './Components/Style/Style';

function App() {

  let [name,updtName] = useState('israil')
  let [count,updtcount] = useState(0)s

  return (
    <div className="App">
      <CmpntInCmpnt />
      <Events />
      <States number="10"/>
      <StatesWithClass />
      <PropsInFun name={name} email="israilgulzar@gmail.com" phone="9499520855" />
      <input type="button" value="web developer" onClick={()=>{updtName('web developer')}} />
      <PropsInClass secondName="props from class" />
      <hr />
      <hr />
      <SingleInputValue/>
      <HideShowToggle/>
      <FormHandle/>
      <ConditionalRender/>
      <Rendering/>
      <CompunentDidMount/>
      <ComponentDidUpdate/>
      <ShouldComponentUpdate/>
      <button onClick={()=>updtcount(! count)}>ComponentWillUnmountBtn</button>
      <>{count == 0? <ComponentWillUnmount/> : <p> this is for testing componentWillUnmount two</p>}</>
      <VdoUseEffect1/>
      <VdoUseEffect2/>
      <Style/>
    </div>
  );
}

export default App;
