import './App.css';
import { useState } from 'react';
import CmpntInCmpnt from './CmpntInCmpnt'
import Events from './Components/Events'
import States from './Components/States'
import StatesWithClass from './Components/StatesWithClass'
import PropsInFun from './Components/PropsInFun'
import PropsInClass from './Components/PropsInClass'
import SingleInputValue from './Components/SingleInputValue'
import HideShowToggle from './Components/HideShowToggle'
import FormHandle from './Components/FormHandle'
import ConditionalRender from './Components/ConditionalRender'

function App() {

  let [name,updtName] = useState('israil')

  return (
    <div className="App">
      {/* <header className="App-header">
        <Test name='israil' email='israilgulzar@gmail.com'/>
      </header> */}
      <CmpntInCmpnt />
      <Events />
      <States number="10"/>
      <StatesWithClass />
      <PropsInFun name={name} email="israilgulzar@gmail.com" phone="9499520855" />
      <input type="button" value="web developer" onClick={()=>{updtName('web developer')}} />
      <PropsInClass secondName="props from class" />
      <hr />
      <hr />
      <SingleInputValue/>
      <HideShowToggle/>
      <FormHandle/>
      <ConditionalRender/>
      

    </div>
  );
}

export default App;
