import React from "react"

const FormHandle = ()=>{

const [name,updtname] = React.useState('') 
const [intrest,updtIntrest] = React.useState('') 
const [gender,updtgender] = React.useState('') 

let submit = (e)=>{
    e.preventDefault()
    console.log('name-->', name);
    console.log('intrest-->', intrest);
    console.log('gender-->', gender);
}
    return(
        <>
            <form action="" onSubmit={submit} style={{color:'red'}}>
               <input type='text' onChange={(e)=>updtname(e.target.value)}/> <br />
               <select  onChange={(e)=>updtIntrest(e.target.value)}>
                   <option> one </option>
                   <option> two </option>
               </select><br />
               <input type="checkbox" style={{transform:'scale(1.5)'}} onChange={(e)=>updtgender(e.target.value)}/><br />
               <input type="submit"/><br />
            </form>
        </>
    )
}
export default FormHandle;