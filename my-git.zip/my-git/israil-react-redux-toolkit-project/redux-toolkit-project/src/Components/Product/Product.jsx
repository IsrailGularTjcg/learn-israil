import React, {useState, useEffect} from 'react';
import { add } from '../../Store/createCartSlice';
import { useDispatch, useSelector } from 'react-redux';
import { fetchProduct, STATUSES } from '../../Store/ProductSlice'

function Product(props) {

    const dispatch = useDispatch();

    const {data :products, status} = useSelector( state => state.product)

    useEffect(()=>{
      
        dispatch(fetchProduct())

    },[])


    const handleAdd = (product)=>{
        // console.log('products', products);
        dispatch(add(product))
    }


    if(status === STATUSES.LOADING){
        return <h2 className='text-center'> LOADING ITEMS .... </h2>
    }
    if(status === STATUSES.ERROR){
        return <h2 className='text-center'> SOME THING WENT WRONG .... </h2>
    }

    return (
        <>
            {products.map((val,i)=>
                <div key={i} className=" custom my-5 d-flex justify-content-center align-items-center">
                    
                    <div className="card p-3">  
                        
                        <div className="d-flex justify-content-between align-items-center ">
                            <div className="mt-2">
                                <h4 className="text-uppercase">{val.id}</h4>
                                <div className="mt-5">
                                    <p className="main-heading mt-0">{val.title}</p>
                                </div>
                            </div>
                            <div className="image">
                                <img src={val.image} width="200"/>
                            </div>
                        </div>

                        <b>price : {val.price}</b>
                        <br />
                        
                        <button onClick={()=>{handleAdd(products[i])}} className="btn btn-danger">Add to cart</button>
                    </div>
                    
                </div>
            )}
        </>
    );
}

export default Product;