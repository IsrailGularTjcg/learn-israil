import React from 'react';
import { useSelector, useDispatch } from 'react-redux'
import { remove } from '../Store/createCartSlice'

function Cart(props) {

    let dispatch = useDispatch()
    let showCartItems = useSelector((state)=>state.cart)

    const removeItem = (productId)=>{
        console.log('helo', productId);
        dispatch(remove(productId)); 
    }

    return (
        <>
            <div  className='container my-5'>
            {showCartItems.map((val,i)=>
                <div key={i} className='row my-5 p-5 shadow'>
                <div className="col-2">
                    <div style={{height:"100px",width:'100px'}}>
                        <img style={{height:"100%",width:'100%'}} src={val.image}/>
                    </div>
                </div>    
                <div className="col-6 m-auto">
                    <div>
                        <p>{val.title}</p>
                    </div>
                </div>    
                <div className="col-2 m-auto">
                    <div>
                        <h5>{val.price} Rs {i} </h5>
                    </div>
                </div>    
                <div className="col-2 m-auto">
                    <div>
                        <button onClick={()=>removeItem(val.id)} className='btn btn-danger' > remove </button>
                    </div>
                </div>    
            </div>
            )}
            </div>
        </>
    );
}

export default Cart;