import React from 'react';
import Product from '../Components/Product/Product';

function Home(props) {
    return (
        <>
        <h2 className='text-center my-5'>
            welcome to the redux Toolkit
        </h2>
        <div className=''>
            <Product/>
        </div>
        </>
    );
}

export default Home;