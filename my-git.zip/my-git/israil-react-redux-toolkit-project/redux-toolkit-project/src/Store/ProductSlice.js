import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

export const STATUSES = Object.freeze({ // enumration for object

    IDLE : 'idle',
    ERROR:'error',
    LOADING: 'loading'

})

const productSlice  = createSlice({

    name : 'product',

    initialState: {

        data: [],
        status: STATUSES.IDLE 

    },

    // new type of creating reducers that are provided by thunk

    extraReducers: (builder)=>{

        builder
        .addCase(fetchProduct.pending,(state, action)=>{
            state.status = STATUSES.LOADING
        })
        .addCase(fetchProduct.fulfilled,(state, action)=>{
            state.data = action.payload
            state.status = STATUSES.IDLE
        })
        .addCase(fetchProduct.rejected, (state, action)=>{
            state.status = STATUSES.ERROR
        })

    }

    // old type of creating reducers via thunk

    // reducers: { //reducer 

    //     setProducts(state, action){ // reducer method for to set the products
            
    //         state.data = action.payload
    //     },
        
    //     setStatus(state, action){ // reducer method for to set the loader
            
    //         state.status = action.payload

    //     }
    // }

})

export const { setProducts , setStatus } = productSlice.actions;

export default productSlice.reducer;


// thunks middleware start here


export const fetchProduct = createAsyncThunk('products/fetch', async ()=>{
    let res = await fetch('https://fakestoreapi.com/products');
    let data = await res.json()
    return data;
})


// old type of featching data via thunk

// export function fetchProduct(){

//     return async function fetchProductThunk(dispatch, getState){

//         dispatch(setStatus(STATUSES.LOADING))
        
//         try {
            
//             let res = await fetch('https://fakestoreapi.com/products');
//             let data = await res.json()
//             dispatch(setProducts(data))
//             dispatch(setStatus(STATUSES.IDLE))
            
//         } catch (error) {
            
//             console.log('error of productSlice', error);
//             dispatch(setStatus(STATUSES.ERROR))
            
//         }
//     } 

// }