import { createSlice } from "@reduxjs/toolkit";

let initialState = [];

const createCartSlice  = createSlice({

    name : 'cart',

    initialState : initialState,

    reducers: {

        add(state, action){
            
            state.push(action.payload)
        },

        remove(state, action){
            return state.filter((item)=>item.id !== action.payload);
        }
    }

})

export const { add , remove } = createCartSlice.actions;

export default createCartSlice.reducer;