import { configureStore } from "@reduxjs/toolkit"; 

import createCartSlice  from "./createCartSlice"
import ProductSlice from "./ProductSlice";


const store = configureStore({

    reducer: {
        cart: createCartSlice,
        product: ProductSlice      
    },

});

export default store;   