import { useDispatch, useSelector } from 'react-redux';
import { incNumber, decNumber } from './Action';
import './App.css';

function App() {

  const myState = useSelector((state)=> state.changeTheNumber);
  const dispatch = useDispatch()

  return (
    <div className="App">
      <br/>
      <br/>
      <br/>
      <h1> 
      Welcome to Redux
      </h1>
      <br/>
      <br/>
        <h3> number are :  {myState}</h3>
      <br/>
      <div >
        <button onClick={()=>dispatch(incNumber())}><b>count up</b></button>
        <button onClick={()=>dispatch(decNumber())}><b>count down</b></button>
      </div>
    </div>
  );
}

export default App;
