import changeTheNumber from './UpAndDown';
import { combineReducers } from 'redux'

const rootReducer = combineReducers({
    changeTheNumber
})

export default rootReducer;