import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Routes, Route, Navigate, } from 'react-router-dom';
import Home from './Components/Home';
import About from './Components/About';
import Navbar from './Components/Navbar';
import User from './Components/User';
import NestedRoute1 from './Components/NestedRoute1';
import NestedRoute2 from './Components/NestedRoute2';
import Login from './Components/Login';
import Protected from './Components/Protected';


function App() {
  return (
    
      <BrowserRouter>
        <Navbar /> 
        <Routes>
         
         <Route path='/' element={<Protected />} /> 
         <Route path='/login' element={<Login/>}/>
         <Route path='/about/' element={<About/>}>
           <Route path='nested1' element={<NestedRoute1/>} />
           <Route path='nested2' element={<NestedRoute2/>} />
         </Route>
         <Route path='/user/:name' element={<User/>}/>
         <Route path='/*' element={<Navigate to="/" />}/>
        </Routes>
      </BrowserRouter>
  );
}

export default App;
