import React from 'react';
import { Link, Outlet } from 'react-router-dom';

function About(props) {
    return (
        <>
            <h1>helo about page</h1>  
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste natus, est deserunt possimus exercitationem, impedit odit laboriosam obcaecati aut eius minima libero fugit dolor tempore nihil quas, quia labore officiis?</p> 
            <Link to="/"> Go to Home </Link>
            <br />
            <Link to="nested1"> Go to nested 1 </Link>
            <br />
            <Link to="nested2"> Go to nested 2 </Link>
            <Outlet/>
        </>
    );
}

export default About;