import React from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';

function Home(props) {    
    const navigate = useNavigate()
    return (
        <>
            <h1>helo home page</h1> 
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste natus, est deserunt possimus exercitationem, impedit odit laboriosam obcaecati aut eius minima libero fugit dolor tempore nihil quas, quia labore officiis?</p> 
            <Link to="/about"> Go to About </Link>
            <Link to="/user/israil" >israil</Link>
            <Link to="/user/amin">amin</Link>
            <hr />
            <button onClick={()=>{navigate('/about')}}>about us</button>

        </>
    );
}

export default Home;