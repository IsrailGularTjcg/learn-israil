import React from 'react';

function Login(props) {
    return (
        <div>
            <input type="email" />
            <input type="password" />
            <button> login </button>
        </div>
    );
}

export default Login;