import React from 'react';
import { Link, NavLink } from 'react-router-dom';


function Navbar(props) {
    return (
        <div>
            {/* <ul>
                <li>
                    <NavLink className="list-item" style={(isActive)=>{return {color: isActive? 'red': 'white'}}} to='/'>Home</NavLink>
                </li>
                <li>
                    <NavLink className="list-item" style={(isActive)=>{return {color: isActive? 'red': 'white'}}} to='/about'>About</NavLink>
                </li>
                <li>
                    <NavLink className="list-item" style={(isActive)=>{return {color: isActive? 'red': 'white'}}} to="/user/israil">israil</NavLink>
                </li>
                <li>
                    <NavLink className="list-item" style={(isActive)=>{return {color: isActive? 'red': 'white'}}} to="/user/amin">amin</NavLink>
                </li>
            </ul> */}
            <ul>
                <li>
                    <NavLink className="list-item" style={(isActive)=>{return {color: isActive? 'red': 'white'}}} to='/'>Home</NavLink>
                </li>
                <li>
                    <NavLink className="list-item" to='/about'>About</NavLink>
                </li>
                <li>
                    <NavLink className="list-item" to="/user/israil">israil</NavLink>
                </li>
                <li>
                    <NavLink className="list-item" to="/user/amin">amin</NavLink>
                </li>
            </ul>
        </div>
    );
}

export default Navbar;