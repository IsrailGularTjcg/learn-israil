import React from 'react';

const NestedRoute1 = () => {
    return (
        <div>
           <h1> helo from ==== NestedRoute1 </h1>
        </div>
    );
};

export default NestedRoute1;