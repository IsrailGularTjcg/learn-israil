import React from 'react';

const NestedRoute2 = () => {
    return (
        <div>
           <h1> helo from ==== NestedRoute2 </h1>
        </div>
    );
};

export default NestedRoute2;