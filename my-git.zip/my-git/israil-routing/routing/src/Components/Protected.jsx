import React from 'react';

function Protected(props) {
    return (
        <div>
            
        </div>
    );
}

export default Protected;