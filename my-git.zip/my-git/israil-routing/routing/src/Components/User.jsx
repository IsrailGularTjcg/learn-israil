import React from 'react';
import { Link, useParams, useSearchParams, useLocation } from 'react-router-dom';

function User(props) {

const params = useParams()

const {name} = params

const [sparams,setSParams] = useSearchParams()

const location = useLocation

console.log('nameOfUser :::>', name);
console.log('useSearchParams :::>', sparams.get('age'));
console.log('useLocation ---->', location());

const age = sparams.get('age')

    return (
        <>
            <center>
                <h1>helo from user {name} search parems {age? age : ''} </h1>
                <ul>
                    <li>
                        <Link to="/user/israil">israil</Link>
                    </li>
                    <li>
                        <Link to="/user/amin" state={{name:'muhammad'}}>amin</Link>
                    </li>
                </ul>  
                <button onClick={()=>{setSParams({age:22})}}>set param</button>
                <input type="text" onChange={(e)=> setSParams({age: e.target.value})} paceholder="set param" />
            </center>
        </>
    );
}

export default User;